
// JngOpcUaClientDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "JngOpcUaClient.h"
#include "JngOpcUaClientDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CJngOpcUaClientDlg �Ի���




CJngOpcUaClientDlg::CJngOpcUaClientDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CJngOpcUaClientDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pCurSelNode = NULL;
	m_nUpdateCount = 0;
}

void CJngOpcUaClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_editUrl);
	DDX_Control(pDX, IDC_COMBO_SECURITY_MODE, m_comboSecurityMode);
	DDX_Control(pDX, IDC_TREE_NODE_ID, m_treeNodeID);
	DDX_Control(pDX, IDC_LIST_NODE_DATA, m_listCtrlNodeData);
	DDX_Control(pDX, IDC_EDIT_NODE, m_editNode);
	DDX_Control(pDX, IDC_EDIT_VALUE, m_editValue);
	DDX_Control(pDX, IDC_EDIT_VALUE_TYPE, m_editValueType);
}

BEGIN_MESSAGE_MAP(CJngOpcUaClientDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_CONNECT, OnBtnConnect)
	ON_BN_CLICKED(IDC_BTN_DISCONNECT, OnBtnDisconnect)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE_NODE_ID, OnTvnSelchangedTreeNodeId)
	ON_BN_CLICKED(IDC_BTN_ADD, OnBnClickedBtnAdd)
	ON_BN_CLICKED(IDC_BTN_REMOVE, OnBnClickedBtnRemove)
	ON_BN_CLICKED(IDC_BTN_SET_VALUE, &CJngOpcUaClientDlg::OnBnClickedBtnSetValue)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST_NODE_DATA, &CJngOpcUaClientDlg::OnLvnItemchangedListNodeData)
END_MESSAGE_MAP()


// CJngOpcUaClientDlg ��Ϣ��������

BOOL CJngOpcUaClientDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	ShowWindow(SW_SHOWNOACTIVATE);

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	m_editUrl.SetWindowTextA("opc.tcp://192.168.0.12:4840");
	m_comboSecurityMode.AddString("None");
	m_comboSecurityMode.AddString("Basi256-Sign");
	m_comboSecurityMode.AddString("Basi256-Sign & Encrypt");
	m_comboSecurityMode.SetCurSel(2);
	

	// list�ؼ�
	m_listCtrlNodeData.InsertColumn(0, "Name", LVCFMT_LEFT, 200);
	m_listCtrlNodeData.InsertColumn(1, "Value", LVCFMT_LEFT, 200);
	m_listCtrlNodeData.InsertColumn(2, "DataType", LVCFMT_CENTER, 80);	
	m_listCtrlNodeData.InsertColumn(3, "NodeID", LVCFMT_LEFT, 200);
	m_listCtrlNodeData.InsertColumn(4, "Status", LVCFMT_CENTER, 100);

	CreateReadThread();

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CJngOpcUaClientDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CJngOpcUaClientDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CJngOpcUaClientDlg::OnBtnConnect()
{
	CString pText;
	m_editUrl.GetWindowTextA(pText);
	int nSecurityMode = m_comboSecurityMode.GetCurSel() + 1;


	// ���ò���
	m_pOpcUaClient.SetSecurityMode(nSecurityMode);
	m_pOpcUaClient.SetVariableChangeCallback(OnUAValuengeNotifyCallback, this);
	m_pOpcUaClient.Connect((LPCTSTR)pText);

	// ��ʾNodeID
	FirstInitNodeID();
}


void CJngOpcUaClientDlg::OnBtnDisconnect()
{
	m_pCurSelNode = NULL;
	m_pOpcUaClient.Disconnect();
}


void CJngOpcUaClientDlg::OnTvnSelchangedTreeNodeId(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);	
	TVITEMA& pItem = pNMTreeView->itemNew;	
	
	if (pItem.lParam != NULL)
	{
		ShowSubNodeID(pItem);		
	}	
	
	*pResult = 0;
}



void CJngOpcUaClientDlg::ShowSubNodeID(TVITEMA& pItem)
{
	// ��ȡ�����Ϣ
	HTREEITEM pTreeItem = pItem.hItem;
	ONE_NODE_DATA* pNodeData = (ONE_NODE_DATA*)pItem.lParam;
	m_pCurSelNode = pNodeData;	// ��¼ѡ�е�NodeID

	if (pNodeData->bExpend)
	{
		// �Ѿ�չ����
		return;
	}

	if (pNodeData->pNodeInfo.nNodeClass != UA_NODE_CLASS::OBJECT)
	{
		// �Ƕ���
		return;
	}

	// ��ȡ���嵥
	std::list<NODE_INFO_CUR> listSubNodeID;
	std::list<NODE_INFO_CUR>::iterator ite;
	CResult rc = m_pOpcUaClient.GetVariableList(pNodeData->pNodeInfo.pNodeID, listSubNodeID);

	//  ��ʾ����
	if (rc.nCode == 0)
	{		
		pNodeData->bExpend = true;
		for (ite = listSubNodeID.begin(); ite != listSubNodeID.end(); ite++)
		{
			ONE_NODE_DATA* pNodeData = NewNodeData();
			pNodeData->pNodeInfo = *ite;

			AddDataToTree(ite->pBrowserName, pTreeItem, pNodeData);
		}

		// ��������
		pItem.cChildren = listSubNodeID.size();
		m_treeNodeID.SetItem(&pItem);
	}
	
}


// ��һ�γ�ʼ��
void CJngOpcUaClientDlg::FirstInitNodeID()
{
	m_treeNodeID.DeleteAllItems();
	HTREEITEM pTreeItem = AddDataToTree("root", NULL, NULL);

	// ���ӳɹ�����ȡ�嵥
	std::string pNodeID;
	std::list<NODE_INFO_CUR> listSubNodeID;
	std::list<NODE_INFO_CUR>::iterator ite;
	m_pOpcUaClient.GetVariableList(pNodeID, listSubNodeID);

	for (ite = listSubNodeID.begin(); ite != listSubNodeID.end(); ite++)
	{
		ONE_NODE_DATA* pNodeData = NewNodeData();
		pNodeData->pNodeInfo = *ite;

		AddDataToTree(ite->pBrowserName, pTreeItem, pNodeData);
	}
		
}


HTREEITEM CJngOpcUaClientDlg::AddDataToTree(std::string pName, HTREEITEM pTreeItem, void* pData)
{
	TV_ITEM tvItem = {0};
	tvItem.mask = TVIF_TEXT | TVIF_PARAM |  TVS_HASBUTTONS; 
	
	tvItem.pszText = (char*)pName.c_str();
	tvItem.cchTextMax = pName.size();
	tvItem.lParam = (LPARAM)pData;		// �������
	tvItem.iImage = 0;				// δ��ѡ��ʱ��ʾ��ͼƬ
	tvItem.iSelectedImage = 0;		// ѡ��ʱ��ʾ��ͼƬ
	tvItem.cChildren = 1;

	TV_INSERTSTRUCT tvInsert = {0};
	tvInsert.hParent = pTreeItem;  // ȷ�����ڵ�
	tvInsert.hInsertAfter = TVI_LAST;
	tvInsert.item = tvItem;       

	HTREEITEM RetItm = m_treeNodeID.InsertItem(&tvInsert);

	m_treeNodeID.Expand(pTreeItem, TVE_EXPAND);

	return RetItm;
}


// �ڵ����ݹ���
ONE_NODE_DATA* CJngOpcUaClientDlg::NewNodeData()
{
	ONE_NODE_DATA* pNodeData = new ONE_NODE_DATA;
	m_listNodeData.push_back(pNodeData);
	return pNodeData;
}



// ���Ӷ�ȡ����
void CJngOpcUaClientDlg::OnBnClickedBtnAdd()
{
	if(m_pCurSelNode != NULL)
	{
		if (m_pCurSelNode->pNodeInfo.nNodeClass == UA_NODE_CLASS::VARIABLE)
		{			
			UA_TYPE::ENUM nType = UA_TYPE::UNSPECIFIED;
			m_pOpcUaClient.GetVariableValue(m_pCurSelNode->pNodeInfo.pNodeID, 
				m_pCurSelNode->pValue, 
				nType);		// ��ȡֵ

			// ���ӵ�list�ؼ�����
			AddOneDataToListCtrl(m_pCurSelNode, nType);
			
			// ����֪ͨ��ʽ
			m_pOpcUaClient.SetVariableChangeNotify(m_pCurSelNode->pNodeInfo.pNodeID);
		}		
	}
}


// �Ƴ���ȡ����
void CJngOpcUaClientDlg::OnBnClickedBtnRemove()
{
	int nCount = m_listCtrlNodeData.GetSelectionMark();
	if(nCount >= 0 && nCount < m_listCtrlNodeData.GetItemCount())
	{
		m_listCtrlNodeData.DeleteItem(nCount);
	}
}

// ����һ������
void CJngOpcUaClientDlg::AddOneDataToListCtrl(ONE_NODE_DATA* pNodeData, UA_TYPE::ENUM nType)
{
	int nCount = m_listCtrlNodeData.GetItemCount();
	CString pText;

	for (int mm = 0; mm < nCount; mm++)
	{
		pText = m_listCtrlNodeData.GetItemText(mm, 3);
		if (pText == pNodeData->pNodeInfo.pNodeID.c_str())
		{
			return;
		}
	}
	char pBuffType[50] = {0};
	sprintf_s(pBuffType, 50, "%d", nType);

	m_listCtrlNodeData.InsertItem(nCount, pNodeData->pNodeInfo.pBrowserName.c_str());
	m_listCtrlNodeData.SetItemText(nCount, 1, pNodeData->pValue.c_str());
	m_listCtrlNodeData.SetItemText(nCount, 2, pBuffType);
	m_listCtrlNodeData.SetItemText(nCount, 3, pNodeData->pNodeInfo.pNodeID.c_str());


}


void CJngOpcUaClientDlg::CreateReadThread()
{
//	_beginthread(ReadThread, 0, this);
}


void CJngOpcUaClientDlg::ReadThread(void* lp)
{
	CJngOpcUaClientDlg* pView = (CJngOpcUaClientDlg*)lp;
	if (pView != NULL)
	{
		pView->ReadHandle();
	}
}

void CJngOpcUaClientDlg::ReadHandle()
{
	while(true)
	{
		ReadHandleClcy();
		//Sleep(1000);
	}	
}

void CJngOpcUaClientDlg::ReadHandleClcy()
{
	UA_TYPE::ENUM nType;
	std::string pValue;
	CString pText;
	int nCount = m_listCtrlNodeData.GetItemCount();
	std::list<ONE_NODE_DATA*>::iterator ite;

	for (int mm = 0; mm < nCount; mm++)
	{
		pText = m_listCtrlNodeData.GetItemText(mm, 3);

		// ��ȡ��Ӧ�ڵ���Ϣ
		pValue = "";
		m_pOpcUaClient.GetVariableValue((LPCTSTR)pText, pValue, nType);
		m_listCtrlNodeData.SetItemText(mm, 1, pValue.c_str());
	}


	m_nUpdateCount++;
}


void CJngOpcUaClientDlg::OnUAValuengeNotifyCallback(const char* pNodeID, 
	const char* pValue, __int32 nSize, __int32 nType, void* pClient)
{
	if (pClient != NULL)
	{
		CJngOpcUaClientDlg* pObject = (CJngOpcUaClientDlg*)pClient;
		pObject->OnUAValuengeNotifyHandle(pNodeID, pValue, nSize, nType);
	}
}


void CJngOpcUaClientDlg::OnUAValuengeNotifyHandle(const char* pNodeID, const char* pValue, __int32 nSize, __int32 nType)
{
	int nCount = m_listCtrlNodeData.GetItemCount();
	std::list<ONE_NODE_DATA*>::iterator ite;
	CString pText;

	for (int mm = 0; mm < nCount; mm++)
	{
		pText = m_listCtrlNodeData.GetItemText(mm, 3);
		if (pText == pNodeID)
		{
			// ��ȡ��Ӧ�ڵ���Ϣ		
			std::string pNewValue;
			pNewValue.append(pValue, nSize);
			m_listCtrlNodeData.SetItemText(mm, 1, pNewValue.c_str());

			char pBuffType[50] = {0};
			sprintf_s(pBuffType, 50, "%d", nType);
			m_listCtrlNodeData.SetItemText(mm, 2, pBuffType);			
		}	
	}
}

// ����ֵ
void CJngOpcUaClientDlg::OnBnClickedBtnSetValue()
{
	CString pNode;
	CString pValue;
	CString pValueType;
	m_editNode.GetWindowText(pNode);
	m_editValue.GetWindowText(pValue);
	m_editValueType.GetWindowText(pValueType);


	if (pNode.GetLength() > 0)
	{
		int nType = ::atoi(pValueType);
		m_pOpcUaClient.SetVariableValue((LPCSTR)pNode, (LPCSTR)pValue, nType);
	}
}


void CJngOpcUaClientDlg::OnLvnItemchangedListNodeData(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);	
	*pResult = 0;

	int nSel = m_listCtrlNodeData.GetSelectionMark();
	CString pText = m_listCtrlNodeData.GetItemText(nSel, 3);	
	m_editNode.SetWindowText(pText);
	
	pText = m_listCtrlNodeData.GetItemText(nSel, 2);	
	m_editValueType.SetWindowText(pText);

}
