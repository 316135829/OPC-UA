
// JngOpcUaClientDlg.h : ͷ�ļ�
//

#pragma once
#include "Input/OpcUaClient.h"
#include "afxwin.h"
#include "afxcmn.h"

// CJngOpcUaClientDlg �Ի���
class CJngOpcUaClientDlg : public CDialogEx
{
// ����
public:
	CJngOpcUaClientDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_JNGOPCUACLIENT_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTvnSelchangedTreeNodeId(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnLvnItemchangedListNodeData(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBtnConnect();
	afx_msg void OnBtnDisconnect();	
	afx_msg void OnBnClickedBtnAdd();
	afx_msg void OnBnClickedBtnRemove();
	afx_msg void OnBnClickedBtnSetValue();

private:
	HTREEITEM AddDataToTree(std::string pName, HTREEITEM pTreeItem, void* pData);
	void ShowSubNodeID(TVITEMA& pItem);
	void FirstInitNodeID();		// ��һ�γ�ʼ��

	ONE_NODE_DATA* NewNodeData();

	// clistctrl����
	void AddOneDataToListCtrl(ONE_NODE_DATA * pNodeData, UA_TYPE::ENUM nType);

	// ��ȡ�ֳ�
	void CreateReadThread();
	static void ReadThread(void* lp);
	void ReadHandle();
	void ReadHandleClcy();

	static void OnUAValuengeNotifyCallback(const char* pNodeID, const char* pValue, __int32 nSize, __int32 nType, void* pClient);
	void OnUAValuengeNotifyHandle(const char* pNodeID, const char* pValue, __int32 nSize, __int32 nType);


private:
	COpcUaClient m_pOpcUaClient;
	
	CEdit m_editUrl;		// OPC server��ַ
	CComboBox m_comboSecurityMode;
	CTreeCtrl m_treeNodeID;
	CListCtrl m_listCtrlNodeData;
	CEdit m_editNode;
	CEdit m_editValue;
	CEdit m_editValueType;

	std::list<ONE_NODE_DATA*> m_listNodeData;
	ONE_NODE_DATA* m_pCurSelNode;					// ѡ���node
	int m_nUpdateCount;
	

	
};
