#include "stdafx.h"
#include "Data.h"


ONE_NODE_DATA::ONE_NODE_DATA()
{
	bExpend =false;
}













