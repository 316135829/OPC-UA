#pragma once
#include "Input/OpcUaClient.h"

struct ONE_NODE_DATA
{
	NODE_INFO_CUR pNodeInfo;
	bool bExpend;				// �Ƿ��Ѿ�չ��
	std::string pValue;

	ONE_NODE_DATA();
};







