#include "stdafx.h"
#include "OpcUaClient.h"

NODE_INFO_CUR::NODE_INFO_CUR()
{
	nNodeClass = UA_NODE_CLASS::UNSPECIFIED;
}

COpcUaClient::COpcUaClient() :
	m_pInterfaceManage("OpcUAClientInterface.dll")
{
	void* pInterface = NULL;
	m_pCallback = NULL;
	m_pClient = NULL;

	m_pInterfaceManage.DllCreateInterface(&pInterface);
	m_pInterface = (COpcUAClientExport*)pInterface;

	
}


COpcUaClient::~COpcUaClient()
{
	m_pInterfaceManage.ReleaseLib();
}


// ���ð�ȫģʽ
void COpcUaClient::SetSecurityMode(int nMode)
{
	if (m_pInterface != NULL)
	{
		m_pInterface->SetSecurityMode(nMode);
	}
}


// ���ӷ����� 
void COpcUaClient::Connect(std::string pEndpointUrl)
{
	if (m_pInterface != NULL)
	{
		m_pInterface->Connect(pEndpointUrl.c_str());
	}
}

// �Ͽ�ͨѶ
void COpcUaClient::Disconnect()
{
	if (m_pInterface != NULL)
	{
		m_pInterface->Disconnect();
	}
}

// ���ݲ���
// ��ȡ�����嵥
CResult COpcUaClient::GetVariableList(std::string pNodeID, std::list<NODE_INFO_CUR>& listSubNodeID)
{
	CResult rc;
	if (m_pInterface != NULL)
	{
		NODE_INFO* pListNode = NULL;
		__int32 nCount = 0;
		rc = m_pInterface->GetVariableList(pNodeID.c_str(), &pListNode, &nCount);

		// ��������
		if (rc.nCode == 0 &&
			pListNode != NULL)
		{
			// ��ȡ����
			listSubNodeID.clear();
			for (int mm = 0; mm < nCount; mm++)
			{
				NODE_INFO_CUR pNode;
				pNode.pNodeID.append(pListNode[mm].pNodeID, pListNode[mm].nNodeIDSize);
				pNode.pBrowserName.append(pListNode[mm].pBrowserName, pListNode[mm].nBrowserNameSize);
				pNode.pDescription.append(pListNode[mm].pDescription, pListNode[mm].nDescriptionSize);
				pNode.nNodeClass = (UA_NODE_CLASS::ENUM)pListNode[mm].nNodeClass;
				listSubNodeID.push_back(pNode);
			}			
		}
		if (pListNode != NULL)
		{
			m_pInterface->GetVariableListFree(pListNode, nCount);
		}
	}

	return rc;
}


// ��ȡ����ֵ
CResult COpcUaClient::GetVariableValue(std::string pNodeID, std::string& pValue, UA_TYPE::ENUM& nType)
{	
	if (m_pInterface != NULL)
	{
		char* pTmpValue = NULL;
		__int32 nSize = 0;
		__int32 nTmpType = 0;

		CResult rc = m_pInterface->GetVariableValue(pNodeID.c_str(), &pTmpValue, &nSize, &nTmpType);
		if (rc.nCode == 0 &&
			pTmpValue != NULL)
		{
			pValue.clear();
			pValue.append(pTmpValue, nSize);
			nType = (UA_TYPE::ENUM)nTmpType;
		}
		if (pTmpValue != NULL)
		{
			m_pInterface->Free(pTmpValue);
		}
	}
	return CResult();
}


// ���ñ���ֵ
CResult COpcUaClient::SetVariableValue(std::string pNodeID, std::string pValue, int nType)
{
	if (m_pInterface != NULL)
	{
		CResult rc = m_pInterface->SetVariableValue(pNodeID.c_str(), pValue.c_str(), pValue.size(), nType);
	}
	return CResult();
}


// ���ñ����ı�֪ͨ���ı��ᴥ���ص�����
CResult COpcUaClient::SetVariableChangeNotify(std::string pNodeID)
{
	if (m_pInterface != NULL)
	{
		char* pTmpValue = NULL;
		__int32 nSize = 0;
		CResult rc = m_pInterface->SetVariableChangeNotify(pNodeID.c_str(), OnUAValuengeNotifyCallback, this);
	}
	return CResult();
}

// ���ñ����ı�֪ͨ�ص�����
void COpcUaClient::SetVariableChangeCallback(UAValuengeNotifyCallback* pCallback, void* pClient)
{
	m_pCallback = pCallback;
	m_pClient = pClient;
}

void COpcUaClient::OnUAValuengeNotifyCallback(const char* pNodeID, const char* pValue, __int32 nSize, __int32 nType, void* pClient)
{
	if (pClient != NULL)
	{
		COpcUaClient* pObject = (COpcUaClient*)pClient;
		pObject->OnUAValuengeNotifyHandle(pNodeID, pValue, nSize, nType);
	}
}


void COpcUaClient::OnUAValuengeNotifyHandle(const char* pNodeID, const char* pValue, __int32 nSize, __int32 nType)
{
	UAValuengeNotifyCallback* pCallback = m_pCallback;
	if (pCallback != NULL)
	{
		pCallback(pNodeID, pValue, nSize, nType, m_pClient);
	}
}



