#pragma once

#ifndef _UA_DATA_DEFINE_
#define _UA_DATA_DEFINE_

// ��ȫ��֤ģʽ
#define UA_SECURITY_MODE_INVALID			0			
#define UA_SECURITY_MODE_NONE				1		
#define UA_SECURITY_MODE_SIGN				2
#define UA_SECURITY_MODE_SIGNANDENCRYPT		3


// �ڵ�����
#define UA_NODE_CLASS_UNSPECIFIED			0
#define UA_NODE_CLASS_OBJECT				1
#define UA_NODE_CLASS_VARIABLE				2
#define UA_NODE_CLASS_METHOD				4
#define UA_NODE_CLASS_OBJECTTYPE			8
#define UA_NODE_CLASS_VARIABLETYPE			16
#define UA_NODE_CLASS_REFERENCETYPE			32
#define UA_NODE_CLASS_DATATYPE				64
#define UA_NODE_CLASS_VIEW					128

// ��������
#define UA_DATA_TYPE_STRING					1	
#define UA_DATA_TYPE_BINARY					2	
#define UA_DATA_TYPE_BOOL					3	
#define UA_DATA_TYPE_INT16					4	
#define UA_DATA_TYPE_INT32					5	
#define UA_DATA_TYPE_INT64					6	
#define UA_DATA_TYPE_UINT16					7	
#define UA_DATA_TYPE_UINT32					8	
#define UA_DATA_TYPE_UINT64					9	
#define UA_DATA_TYPE_FLOAT					10	
#define UA_DATA_TYPE_DOUBLE					11	



struct CResult
{
	__int32 nCode;		// �������
	char pText[200];	// ������Ϣ	

	CResult()
	{
		nCode = 0;
		memset(pText, 0, 200);
	}
	CResult(__int32 nCode, const char* pText)
	{
		SetData(nCode, pText);
	}
	void SetData(__int32 nCode, const char* pText)
	{
		this->nCode = nCode;
		memset(this->pText, 0, 200);
		if (pText != NULL &&
			this->nCode != 0)
		{
			strncpy_s(this->pText, 200, pText, 200);
		}
	}
};


// �ڵ���Ϣ
struct NODE_INFO
{
	char* pNodeID;				// ��ʶ��
	__int32 nNodeIDSize;
	char* pBrowserName;			// �������
	__int32 nBrowserNameSize;
	char* pDescription;			// ����
	__int32 nDescriptionSize;
	__int32 nNodeClass;			// �ڵ�����
};

/* ���ݸı�֪ͨ�ص� */
typedef void (UAValuengeNotifyCallback)(const char* pNodeID, const char* pValue, __int32 nSize, __int32 nType, void* pClient);

#endif

class COpcUAClientExport
{
public:
	virtual void SetSecurityMode(__int32 nMode) = 0;			// ���ð�ȫģʽ
	virtual CResult Connect(const char* pEndpointUrl) = 0;		// ���ӷ����� 
	virtual void Disconnect() = 0;								// �Ͽ�ͨѶ
	virtual void Free(void* pObject) = 0;

	// ���ݲ���
	virtual CResult GetVariableList(const char* pNode, NODE_INFO** pListName, __int32* nCount) = 0;	// ��ȡ�����嵥
	virtual void GetVariableListFree(NODE_INFO* pListName, __int32 nCount) = 0;					// �ͷű����嵥
	virtual CResult GetVariableValue(const char* pNode, char** pValue, __int32* nSize, __int32* nType) = 0;					// ��ȡ����ֵ
	virtual CResult SetVariableValue(const char* pNode, const char* pValue, __int32 nSize, __int32 nType) = 0;				// ���ñ���ֵ
	virtual CResult SetVariableChangeNotify(const char* pNode, UAValuengeNotifyCallback* pCallback, void* pClient) = 0;		// ���ñ����ı�֪ͨ���ص�����
};					
















